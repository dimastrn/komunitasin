<?php 
/**
 * 
 */
class ClassName extends AnotherClass
{
	
	function __construct(argument)
	{
		# code...
	}
}

 ?>