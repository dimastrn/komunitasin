<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {	
	
	public $nama = "Adimas Sastra Nugraha";
	public $judul = "WEBku";
	public $data = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";					
	public $alamat = "Silicon Valley";
	public $gender = "Pria";
	public $asal_sekolah = "SMKTI PELITA NUSANTARA KEDIRI";
	public $email = "adimassn@gmail.com";
	public $telp = "+62-8161-555-4005";


	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{				
		$this->load->view('hello');
	}

	public function biodata()
	{
		$data = [
			'nama' => $this->nama,
			'judul' => $this->judul,
			'isi' => $this->data,
			'alamat' => $this->alamat,
			'gender' => $this->gender,
			'asal_sekolah' => $this->asal_sekolah,
			'email' => $this->email,
			'telp' => $this->telp
		];		
		$this->load->view('hello', $data);		
	}

}
