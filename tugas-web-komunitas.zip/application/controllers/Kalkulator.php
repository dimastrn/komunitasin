
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kalkulator extends CI_Controller {		
	private $_operator;	

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{				
		$this->load->view('kalkulator');
	}

	public function menu()
	{		
		$link = $this->uri->segment(3);
		$data['title'] = $link;		
		$this->load->view('menu_kalkulator/'.$link, $data);
	}

	public function proses($bil1, $bil2)
	{
		switch ($this->_operator) {
			case 'rkali':
				$hasil = $bil1 * $bil2;	
				break;
			case 'rtambah':
				$hasil = $bil1 + $bil2;	
				break;
			case 'ngurang':
				$hasil = $bil1 - $bil2;	
				break;
			case 'mbagi':
				$hasil = $bil1 / $bil2;	
				break;							
			default:				

				break;
		}
		return $hasil;
	}

	public function hitung()
	{
		$post = $this->input->post();		
		$operator_mat = $post['operator'];		
		if($operator_mat == 'rkali' || $operator_mat == 'rtambah' || $operator_mat == 'ngurang' || $operator_mat == 'mbagi') {
			$this->_operator = $post['operator'];
			$link_title = 'pe'.$this->_operator.'an';
			$data['title'] = $link_title;
			$data['bil1'] = $post['bil1'];
			$data['bil2'] = $post['bil2'];		
			$data['hitung'] = $this->proses($data['bil1'], $data['bil2']);		
			$this->load->view('menu_kalkulator/'.$link_title, $data);
		}						
	}



}
