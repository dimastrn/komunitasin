
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Praktikum_database extends CI_Model {

    

}


 ?>