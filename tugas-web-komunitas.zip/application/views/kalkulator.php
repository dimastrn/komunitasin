<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Compiled and minified CSS -->
  	<!-- Compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">

  <!-- Compiled and minified JavaScript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
  
</head>
<body>

	<div class="container">
		<h1 class="center-align">MENU KALKULATOR</h1>
		<div class="row">
        <div class="col s12 m6">
          <div class="card blue-grey darken-1">
            <div class="card-content white-text">
              <span class="card-title">Pertambahan</span>             
            </div>
            <div class="card-action">
              <?php echo anchor('kalkulator/menu/pertambahan', 'Hitung'); ?>
            </div>
          </div>
        </div>
        <div class="col s12 m6">
          <div class="card blue-grey darken-2">
            <div class="card-content white-text">
              <span class="card-title">Pengurangan</span>             
            </div>
            <div class="card-action">
              <?php echo anchor('kalkulator/menu/pengurangan', 'Hitung'); ?>
            </div>
          </div>
        </div>       
      </div>
      <div class="row">
      	 <div class="col s12 m6">
          <div class="card blue-grey darken-3">
            <div class="card-content white-text">
              <span class="card-title">Perkalian</span>             
            </div>
            <div class="card-action">
              <?php echo anchor('kalkulator/menu/perkalian', 'Hitung'); ?>
            </div>
          </div>
        </div>
        <div class="col s12 m6">
          <div class="card blue-grey darken-4">
            <div class="card-content white-text">
              <span class="card-title">Pembagian</span>             
            </div>
            <div class="card-action">
              <?php echo anchor('kalkulator/menu/pembagian', 'Hitung'); ?>
            </div>
          </div>
        </div>
      </div>
	</div>
	
</body>
</html>