<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Compiled and minified CSS -->
  	<!-- Compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">


  
</head>
<body>

	<div class="container">
		<div class="card">
			<div class="card-content">
				<h1 style="text-transform: capitalize;"><?php echo $title ?></h1>
				<?php echo form_open('kalkulator/hitung', 'method="POST"'); ?>
				<div class="input-field col s12">
					<?php echo form_input('bil1', '','class="validate" placeholder="Bilangan 1"') ?>							
				</div>
				<div class="input-field col s12">
					<?php echo form_input('bil2', '','class="validate" placeholder="Bilangan 2"') ?>							
				</div>
				<?php echo form_input('operator', 'ngurang', 'hidden') ?>
				<?php echo form_submit('submit', 'Submit', 'class="waves-effect waves-light btn"'); ?>
				<?php echo anchor('kalkulator', 'Kembali', 'class="waves-effect waves-light btn"') ?>
				<?php echo form_close(); ?>	
				<h1>Hasil: <?php echo @$hitung; ?></h1>
			</div>
		</div>
	</div>

	
	  <!-- Compiled and minified JavaScript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
	
</body>
</html>