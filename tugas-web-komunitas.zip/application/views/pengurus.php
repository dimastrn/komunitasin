<!DOCTYPE html>
<html lang="en">
<head>
    <meta acharset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Table Komunitas</title>
    <link href="<?php echo base_url('assets/css/bootstrap.css'); ?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/fresh-bootstrap-table.css'); ?>" rel="stylesheet" />
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
</head>
<body>

<div class="wrapper">
    <div class="fresh-table toolbar-color-azure full-screen-table">
    <!--    Available colors for the full background: full-color-blue, full-color-azure, full-color-green, full-color-red, full-color-orange                  
            Available colors only for the toolbar: toolbar-color-blue, toolbar-color-azure, toolbar-color-green, toolbar-color-red, toolbar-color-orange
    -->
        
        <div class="toolbar">
            <button id="alertBtn" class="btn btn-default" data-toggle="modal" data-target="#add-modal"><i class="fa fa-plus"></i> Tambah Data</button>
        </div>
        
        <table id="fresh-table" class="table">
            <thead>
                <th data-field="no" data-sortable="true">No</th>
                <th data-field="id" data-sortable="true">ID</th>
            	<th data-field="nama" data-sortable="true">Nama</th>
            	<th data-field="alamat" data-sortable="true">Alamat</th>
            	<th data-field="gaji" >Gaji</th>
            	<th data-field="gender">Gender</th>
            	<th data-field="actions">Actions</th>
            </thead>
            <tbody>       
                <?php 
                    $no = 1;
                    foreach($komunitas as $data): 
                ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $data['id_komunitas']; ?></td>
                        <td><?php echo $data['nama']; ?></td>
                        <td><?php echo $data['alamat']; ?></td>
                        <td><?php echo $data['gaji']; ?></td>
                        <td><?php echo $data['gender']; ?></td>                        
                        <td>                   
                            <a rel="tooltip" title="Edit" class="table-action edit" href="<?php echo site_url('pengurus/edit/').$data['id_komunitas'] ?>" title="Edit">
                                <i class="fa fa-edit"></i>
                            </a>
                            <a rel="tooltip" title="Remove" class="table-action remove" href=<?php echo site_url('pengurus/delete/').$data['id_komunitas'] ?>" title="Remove">
                                <i class="fa fa-remove"></i>
                            </a>
                        </td>
                    </tr> 
                <?php endforeach; ?>              
            </tbody>
        </table>
    </div>
    
    <!-- Modal -->
    <div class="modal fade" id="add-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <?php echo form_open('pengurus/tambah'); ?>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
        
                <div class="form-group">
                    <label>Nama</label>
                    <?php echo form_input('nama', '', 'class="form-control" placeholder="Masukan Nama"'); ?>
                </div>

                        
                <div class="form-group">
                    <label>Alamat</label>
                    <?php echo form_input('alamat', '', 'class="form-control" placeholder="Masukan Alamat"'); ?>
                </div>

                <div class="form-group">
                    <label>Gaji</label>
                    <?php echo form_input('gaji', '', 'class="form-control" placeholder="Masukan Gaji"'); ?>
                </div>

                <div class="form-group">
                    <label>Gender</label>                    
                    <?php 
                        $data = array(  
                            '' => 'Pilih',
                            'pria' => 'Pria',
                            'wanita' => 'Wanita'
                        );
                        echo form_dropdown('gender', $data, '','class="form-control"'); 
                    ?>                    
                </div>                
            

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            
            </div>
        </div>
        <?php echo form_close(); ?>
    </div>

</div>


<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap-table.js') ?>"></script>

<script type="text/javascript">
        if(navigator.onLine) { // true|false
            alert("YESS kamu tekoneksi Internet ^_^");
        } else {
            alert("Plsss Konek ke Internet supaya lebih maksimal >.<");
        }
        
        var $table = $('#fresh-table'),            
            full_screen = false,
            window_height;
            
        $().ready(function(){
            
            window_height = $(window).height();
            table_height = window_height - 20;
            
            
            $table.bootstrapTable({
                toolbar: ".toolbar",

                showRefresh: false,
                search: true,
                showToggle: true,
                showColumns: true,
                pagination: true,
                striped: true,
                sortable: true,
                height: table_height,
                pageSize: 10,
                pageList: [10,50,100],
                
                formatShowingRows: function(pageFrom, pageTo, totalRows){
                    //do nothing here, we don't want to show the text "showing x of y from..." 
                },
                formatRecordsPerPage: function(pageNumber){
                    return pageNumber + " rows visible";
                },
                icons: {
                    refresh: 'fa fa-refresh',
                    toggle: 'fa fa-th-list',
                    columns: 'fa fa-columns',
                    detailOpen: 'fa fa-plus-circle',
                    detailClose: 'fa fa-minus-circle'
                }
            });                          
                    
            $(window).resize(function () {
                $table.bootstrapTable('resetView');
            });    
        });
        
        
       
    </script>
    
</body>
</html>