<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Compiled and minified CSS -->
  <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style type="text/css">
      body {
        background-color: #ef5350;
      }
    </style>

</head>
<body>
  
	   <div class="section no-pad-bot" id="index-banner">
      <div class="container">   

        <div class="col s12 m6">
        <div class="card horizontal z-depth-4">          
          <div class="card-image">
            <img src="<?php echo base_url('assets').'/img/realme.jpg' ?>" style="height: 573px;">                                
          </div>
          <div class="card-stacked">
              <div class="card-content grey-text">
              <h5><i class="fa fa-briefcase fa-fw"></i> <?php echo $asal_sekolah; ?></h5>
              <h5><i class="fa fa-home fa-fw"></i> <?php echo $alamat; ?></h5>
              <h5><i class="fa fa-mars fa-fw"></i> <?php echo $gender; ?></h5>
              <h5><i class="fa fa-envelope fa-fw"></i> <?php echo $email; ?></h5>
              <h5><i class="fa fa-phone fa-fw"></i> <?php echo $telp; ?></h5>          
              <br>          
              <span class="card-title"><i class="fa fa-user"></i> <b>About Me</b></span>          
              <p>
                <?php echo $isi; ?>
              </p>
            </div> 
            <div class="card-action">
              <a href="#">Contact</a>
            </div>
          </div>
               
        </div>
      </div>       

    </div>
  </div>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>